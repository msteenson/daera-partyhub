import * as dragulaExpt from 'dragula';
export const dragula: (value?: any) => any = (dragulaExpt as any).default || dragulaExpt;
